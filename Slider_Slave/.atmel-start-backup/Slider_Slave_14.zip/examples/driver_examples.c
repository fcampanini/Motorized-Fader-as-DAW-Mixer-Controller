/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

/*! The buffer size for ADC */
#define ADC_DMA_BUFFER_SIZE 16
static uint8_t ADC_DMA_buffer[ADC_DMA_BUFFER_SIZE];

static void convert_cb_ADC_DMA(const struct adc_dma_descriptor *const descr)
{
}

/**
 * Example of using ADC_DMA to generate waveform.
 */
void ADC_DMA_example(void)
{
	/* Enable ADC freerun mode in order to make example work */
	adc_dma_register_callback(&ADC_DMA, ADC_DMA_COMPLETE_CB, convert_cb_ADC_DMA);
	adc_dma_enable_channel(&ADC_DMA, 0);
	adc_dma_read(&ADC_DMA, ADC_DMA_buffer, ADC_DMA_BUFFER_SIZE);
}

static struct io_descriptor *io;

static void I2C_COMM_rx_complete(const struct i2c_s_async_descriptor *const descr)
{
	uint8_t c;

	io_read(io, &c, 1);
}

void I2C_COMM_example(void)
{
	i2c_s_async_get_io_descriptor(&I2C_COMM, &io);
	i2c_s_async_register_callback(&I2C_COMM, I2C_S_RX_COMPLETE, I2C_COMM_rx_complete);
	i2c_s_async_enable(&I2C_COMM);
}

static struct timer_task TIMER_task1, TIMER_task2;
/**
 * Example of using TIMER.
 */
static void TIMER_task1_cb(const struct timer_task *const timer_task)
{
}

static void TIMER_task2_cb(const struct timer_task *const timer_task)
{
}

void TIMER_example(void)
{
	TIMER_task1.interval = 100;
	TIMER_task1.cb       = TIMER_task1_cb;
	TIMER_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_task2.interval = 200;
	TIMER_task2.cb       = TIMER_task2_cb;
	TIMER_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER, &TIMER_task1);
	timer_add_task(&TIMER, &TIMER_task2);
	timer_start(&TIMER);
}

/**
 * Example of using TIMER_ADC.
 */
struct timer_task TIMER_ADC_task1, TIMER_ADC_task2;

static void TIMER_ADC_task1_cb(const struct timer_task *const timer_task)
{
}

static void TIMER_ADC_task2_cb(const struct timer_task *const timer_task)
{
}

void TIMER_ADC_example(void)
{
	TIMER_ADC_task1.interval = 100;
	TIMER_ADC_task1.cb       = TIMER_ADC_task1_cb;
	TIMER_ADC_task1.mode     = TIMER_TASK_REPEAT;
	TIMER_ADC_task2.interval = 200;
	TIMER_ADC_task2.cb       = TIMER_ADC_task2_cb;
	TIMER_ADC_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER_ADC, &TIMER_ADC_task1);
	timer_add_task(&TIMER_ADC, &TIMER_ADC_task2);
	timer_start(&TIMER_ADC);
}
