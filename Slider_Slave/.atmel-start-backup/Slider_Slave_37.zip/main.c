/*
* Syntax for git bush push is git push SAMD11_Slider_Slave
* URL for remote repository is already set and stored
* Filippo Campanini
*/


#include <atmel_start.h>
#include <stdbool.h>
#include "Ring_Buffer/RingBuffer.h"

#define IO_DIRSET_A	PORT->Group[0].DIRSET.reg
#define IO_OUTSET_A	PORT->Group[0].OUTSET.reg
#define IO_OUTCLR_A	PORT->Group[0].OUTCLR.reg
#define IO_OUTTLG_A	PORT->Group[0].OUTTGL.reg

#define LED_PWR		PORT_PA05
#define LED_OPR		PORT_PA08
#define LED_TOUCH	PORT_PA09
#define LED_TEST	PORT_PA04

#define PWM_SPEED		6
#define PWM_FULL_SPEED	10
#define ADC_OFFSET		150

#define ADC_SAMPLE_RATE 1
#define ADC_DMA_BUFFER_SIZE 16

#define I2C_SLAVE_ADDR	0x15

/*----------------------------QTOUCH----------------------------*/
extern volatile uint8_t measurement_done_touch;
static uint8_t key_status = 0;
volatile bool isTouch;
volatile bool wasTouch;
static void touch_status_display(void);
/*--------------------------------------------------------------*/

/*----------------------------TCC0-------------------------------*/
static struct timer_task TIMER_ADC_task1, TIMER_ADC_task2;
static void TIMER_ADC_ini(void); // TC1 init
static void TIMER_ADC_task1_cb(const struct timer_task \
*const timer_task); // TCC0 task1 OVF handler
static void TIMER_ADC_task2_cb(const struct timer_task \
*const timer_task); // TCC0 task2 OVF handler
/*--------------------------------------------------------------*/

/*----------------------------ADC DMA-------------------------------*/
volatile uint16_t adc_result;
volatile uint16_t old_adc_result;
static uint16_t ADC_DMA_buffer[ADC_DMA_BUFFER_SIZE];
static void ADC_DMA_init(void);
static void ADC_DMA_complete_cb(const struct adc_dma_descriptor *const descr);
static void ADC_DMA_error_cb(const struct adc_dma_descriptor *const descr);
/*--------------------------------------------------------------*/

/*-------------------------------PWM----------------------------*/
volatile uint8_t up_speed;
volatile uint8_t down_speed;
volatile uint16_t pot_max_value;
volatile uint16_t pot_min_value;
volatile uint16_t reference_value;
static void TC2_init(void);
/*--------------------------------------------------------------*/

/*-------------------------------I2C----------------------------*/
struct io_descriptor *I2C_COMM_io;
volatile bool i2c_is_tx_complete;
volatile bool i2c_is_rx_complete;
volatile bool i2c_is_error;
volatile bool i2c_is_pending;
//volatile uint8_t i2c_data_buffer[3]={0x7f,0x5f,0x4f};
volatile uint8_t i2c_data_buffer[3];
volatile uint8_t i2c_read_data_buffer[2];
volatile uint8_t i2c_read_data_tmp_buffer;
volatile uint8_t i2c_ring_temp;
volatile struct Buffer I2C_ring_buffer = {{}, 0, 0};
volatile uint8_t i2c_index;
static void I2C_init(void);
static void I2C_tx_complete_cb(struct i2c_s_async_descriptor *const i2c);
static void I2C_rx_complete_cb(struct i2c_s_async_descriptor *const i2c);
static void I2C_error_cb(struct i2c_s_async_descriptor *const i2c);
static void I2C_tx_pending_cb(struct i2c_s_async_descriptor *const i2c);
/*--------------------------------------------------------------*/

/*-------------------------------MOTOR----------------------------*/
void move_motor_up(uint8_t speed);
void move_motor_down(uint8_t speed);
void break_motor(void);
void calibration(void);
/*--------------------------------------------------------------*/

volatile bool isOperating;
volatile int test;
uint32_t ret;

/*--------------------------------------------------------------------------------------MAIN Function and Infinite Loop----------------------------------------------------------------------------------*/

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	__disable_irq();

	atmel_start_init();
	TIMER_ADC_ini();
	ADC_DMA_init();
	TC2_init();
	I2C_init();

	NVIC->ISER[0] |= (1 << 14); // Enable the interrupt IRQ (14) for the TC2;

	PORT->Group[0].PINCFG[6].reg |= 0x01; // Set PA6 as Alternative MUX function
	PORT->Group[0].PMUX[3].reg = 0x04; // Set PA6 as WO[0] for TC2

	PORT->Group[0].PINCFG[7].reg |= 0x01; // Set PA7 as Alternative MUX function
	PORT->Group[0].PMUX[3].reg |= (0x40 & 0xF0); // Set PA7 as WO[1] for TC2

	PORT->Group[0].PINCFG[24].reg |= (1 << 2); // enable pull up resistor (as pr datasheet indication)
	PORT->Group[0].PINCFG[25].reg |= (1 << 2); // enable pull up resistor (as pr datasheet indication)

	__enable_irq();

	IO_DIRSET_A = LED_PWR; // Set direction for POWER LED
	IO_OUTSET_A = LED_PWR; // Set HIGH for POWER LED
	IO_DIRSET_A = LED_OPR; // Set direction for OPERATION LED
	IO_DIRSET_A = LED_TOUCH; // Set direction for TOUCH LED
	IO_DIRSET_A = LED_TEST; // Set direction for LED test

	down_speed = 0;
	up_speed = 0;
	reference_value = 11800;

	calibration();

	i2c_is_tx_complete = true;
	i2c_is_rx_complete = true;

	while (1)
	{
		touch_process();
		if (measurement_done_touch == 1)
		{
			touch_status_display();
		}
		
		if(isTouch)
		{
			if(!wasTouch)
			{
				wasTouch = true;
				
				i2c_data_buffer[0] = 0x01;
				i2c_data_buffer[1] = 0x18; //LSB
				i2c_data_buffer[2] = 0x7F; //MSB
			}
			
			if(adc_result >= (old_adc_result + 60) || adc_result <= (old_adc_result - 60))
			{
				reference_value = adc_result;
				old_adc_result = reference_value;

				if (adc_result >= (pot_max_value - 20)) //compensate at top value
				{
					adc_result = 16383;
				}
				
				if(adc_result <= (pot_min_value + 20)) //compensate at bottom value
				{
					adc_result = 0;
				}
				
				i2c_data_buffer[0] = 0x00;
				i2c_data_buffer[2] = ((adc_result >> 7) & 0x7F); //LSB
				i2c_data_buffer[1] = (adc_result & 0x7F); //MSB
				
				if(i2c_is_pending)
				{
					
					i2c_is_pending = false;
				}
			}
			
		}
		else if(!isTouch)
		{
			if(wasTouch)
			{
				wasTouch = false;
				
				i2c_data_buffer[0] = 0x01;
				i2c_data_buffer[1] = 0x18; //LSB
				i2c_data_buffer[2] = 0x00; //MSB
			}
		}
		

		if((reference_value > (adc_result + ADC_OFFSET)) && (reference_value < pot_max_value) && !isTouch )
		{
			move_motor_up(PWM_SPEED);
			while((reference_value - ADC_OFFSET) > adc_result){isOperating = true;}
			break_motor();
		}
		
		if((reference_value < (adc_result - ADC_OFFSET)) && (reference_value > pot_min_value) && !isTouch)
		{
			move_motor_down(PWM_SPEED);
			while((reference_value + ADC_OFFSET) < adc_result){isOperating = true;}
			break_motor();
		}
		
		uint8_t testBuffer;
		enum BufferStatus status;
		
		status = bufferCheck(&I2C_ring_buffer, &testBuffer);
		
		if( status == BUFFER_OK)
		{
			
			//Read data from master 
			bufferRead(&I2C_ring_buffer, &i2c_ring_temp);

			if(i2c_index == 0)
			{
				i2c_index = 1;
			}
			else if(i2c_index == 1)
			{
				i2c_index = 0;
			}
			
			i2c_read_data_buffer[i2c_index] = i2c_ring_temp;

			//Set position
			if(!isTouch && i2c_index == 0)
			{
				reference_value = ((i2c_read_data_buffer[1] << 7) | (i2c_read_data_buffer[0] & 0x7F));
				
				//if(reference_value <= (pot_min_value - ADC_OFFSET))reference_value = 0;
				//if(reference_value >= (pot_max_value + ADC_OFFSET))reference_value = 16383;
			}
		}
	}
}

/*--------------------------------------------------------------------------------------Calls back event Handlers----------------------------------------------------------------------------------------*/

static void TIMER_ADC_ini()
{
	TIMER_ADC_task1.interval = ADC_SAMPLE_RATE;
	TIMER_ADC_task1.cb       = TIMER_ADC_task1_cb;
	TIMER_ADC_task1.mode     = TIMER_TASK_REPEAT;

	TIMER_ADC_task2.interval = 50;
	TIMER_ADC_task2.cb       = TIMER_ADC_task2_cb;
	TIMER_ADC_task2.mode     = TIMER_TASK_REPEAT;

	timer_add_task(&TIMER_ADC, &TIMER_ADC_task1);
	timer_add_task(&TIMER_ADC, &TIMER_ADC_task2);
	timer_start(&TIMER_ADC);
}

static void ADC_DMA_init(void)
{
	adc_dma_register_callback(&ADC_DMA, ADC_DMA_COMPLETE_CB, ADC_DMA_complete_cb);
	adc_dma_register_callback(&ADC_DMA, ADC_DMA_ERROR_CB, ADC_DMA_error_cb);
	adc_dma_enable_channel(&ADC_DMA, 0);
}

static void TC2_init()
{
	PM->APBCMASK.reg |= (1 <<  7); // Enable periferial BUS for TC2

	GCLK->CLKCTRL.reg = 0;
	GCLK->CLKCTRL.reg = (1 << 14) | (0x04 << 8) | 0x12; // enable generic clock, select 4 as generic clock source and assign TC2 id
	//GCLK->CLKCTRL.reg = 0x4312;

	TC2->COUNT8.CTRLA.reg |= (1 << 0); // Sofware reset and TC2 disable
	while((TC2->COUNT8.CTRLA.reg & 0x1) == 1){} // wait until TC2 is reset and disabled
	//TC2->COUNT8.CTRLA.reg |= (3 << 8); // Prescale 8 (8.000.000/8 = 1.000.000)
	TC2->COUNT8.CTRLA.reg |= (1 << 2) | (1 << 6); // Set 8bit mode, NPWM
	TC2->COUNT8.PER.reg = 10; // 1.000.000/ 10 = 100KHz period
	TC2->COUNT8.CC[0].reg = 0;
	TC2->COUNT8.CC[1].reg = 0;
	//TC2->COUNT8.CTRLC.reg |= (1 << 1);
	TC2->COUNT8.INTENSET.reg = 0x01;
	TC2->COUNT8.CTRLA.reg |= (1 << 1); // enable the counter
}

static void I2C_init(void)
{
	i2c_s_async_get_io_descriptor(&I2C_COMM, &I2C_COMM_io);
	i2c_s_async_set_addr(&I2C_COMM, I2C_SLAVE_ADDR);
	i2c_s_async_register_callback(&I2C_COMM, I2C_S_RX_COMPLETE, I2C_rx_complete_cb);
	i2c_s_async_register_callback(&I2C_COMM, I2C_S_TX_COMPLETE, I2C_tx_complete_cb);
	i2c_s_async_register_callback(&I2C_COMM, I2C_S_ERROR, I2C_error_cb);
	i2c_s_async_register_callback(&I2C_COMM, I2C_S_TX_PENDING, I2C_tx_pending_cb);
	i2c_s_async_enable(&I2C_COMM);
}

static void TIMER_ADC_task1_cb(const struct timer_task *const timer_task)
{
	adc_dma_read(&ADC_DMA, ADC_DMA_buffer, ADC_DMA_BUFFER_SIZE);
	test = 1;
}

static void TIMER_ADC_task2_cb(const struct timer_task *const timer_task)
{
	if(isOperating && ((old_adc_result + 100) < adc_result ||  (old_adc_result - 100) > adc_result))
	{
		IO_OUTTLG_A = LED_OPR;
	}
	else
	{
		IO_OUTCLR_A = LED_OPR;
	}

	//old_adc_result = adc_result;
	isOperating = false;
}

static void ADC_DMA_complete_cb(const struct adc_dma_descriptor *const descr)
{
	uint32_t tmp = 0;

	for( int n = 0; n < ADC_DMA_BUFFER_SIZE; n++)
	{
		tmp += ADC_DMA_buffer[n];
	}

	adc_result = tmp/ADC_DMA_BUFFER_SIZE;
	test = 1;
}

static void ADC_DMA_error_cb(const struct adc_dma_descriptor *const descr)
{

}

void TC2_Handler()
{
	if(TC2->COUNT8.INTFLAG.reg & 0x01)
	{
		TC2->COUNT8.CC[0].reg = down_speed;
		TC2->COUNT8.CC[1].reg = up_speed;
		TC2->COUNT8.INTFLAG.reg = 1; // clear overflow flag
	}
}

static void I2C_tx_complete_cb(struct i2c_s_async_descriptor *const i2c)
{
	i2c_is_tx_complete = true;
	i2c_is_pending = false;
}

static void I2C_tx_pending_cb(struct i2c_s_async_descriptor *const i2c)
{
	i2c_is_tx_complete = false;
	i2c_is_pending = true;
	io_write(I2C_COMM_io, i2c_data_buffer, 3);
}

static void I2C_rx_complete_cb(struct i2c_s_async_descriptor *const i2c)
{
	i2c_is_rx_complete = true;
	io_read(I2C_COMM_io, &i2c_read_data_tmp_buffer, 1);
	bufferWrite(&I2C_ring_buffer,  i2c_read_data_tmp_buffer);
}

static void I2C_error_cb(struct i2c_s_async_descriptor *const i2c)
{
	i2c_is_error = true;
	IO_OUTSET_A = LED_TEST;
}

/*--------------------------------------------------------------------------------------Other private functions--------------------------------------------------------------------------------------*/

void move_motor_up(uint8_t speed)
{
	down_speed = 0;
	up_speed = speed;
}

void move_motor_down(uint8_t speed)
{
	down_speed = speed;
	up_speed = 0;
}

void break_motor()
{
	down_speed = 0;
	up_speed = 0;
}

void calibration()
{
	move_motor_up(PWM_FULL_SPEED);
	delay_ms(500);
	pot_max_value = adc_result;

	move_motor_down(PWM_FULL_SPEED);
	delay_ms(500);
	pot_min_value = adc_result;

	break_motor();
}

void touch_status_display(void)
{
	key_status = get_sensor_state(0) & 0x80;

	if (0u != key_status)
	{
		// LED_ON
		IO_OUTSET_A = LED_TOUCH;
		isTouch = true;
		isOperating = true;
	}
	else
	{
		// LED_OFF
		IO_OUTCLR_A = LED_TOUCH;
		isTouch = false;
	}
}